# SimpleWeb-With-JSON (masih tahap pengembangan)
Website dibuat dalam rangka latihan menerapkan <b>Repository Pattern</b> pada Back-End menggunakan PHP vanilla (Driver database menggunakan PDO untuk php OOP). Untuk Front-End framework CSS menggunakan <b>TailwindCSS</b> dan framework JavaScript menggunakan <b>AlpineJS</b>, disini AlpineJS juga digunakan untuk melakukan promise fetch respond json dari back end.
> - jangan lupa npm install untuk alpinejs
> - pastikan server mengizinkan .htaccess
